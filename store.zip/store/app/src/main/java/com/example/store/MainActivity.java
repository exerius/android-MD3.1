package com.example.store;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    Button btnSave, btnLoad;
    EditText etName, date;
    SeekBar age;
    TextView age_view;
    String[] groups = {"ПИ20-1", "ПИ20-2"};
    Spinner spinner;
    int mMonth, mDay, mYear;
    ImageView image;
    Uri photoUri;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = findViewById(R.id.imageView4);
        btnSave = findViewById(R.id.btnSave);
        btnLoad = findViewById(R.id.btnLoad);
        etName = findViewById(R.id.etName);
        age = findViewById(R.id.seekBar);
        age_view = findViewById(R.id.textView2);
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, groups);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        age_view.setText(String.valueOf(age.getProgress()));
        date = findViewById(R.id.editTextDate);
        age.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                age_view.setText(String.valueOf(i));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        SharedPreferences pref = getPreferences(MODE_PRIVATE);
        etName.setText(pref.getString("name", ""));
        age.setProgress(pref.getInt("age", 0));
        spinner.setSelection(pref.getInt("group", 0));
        date.setText(pref.getString("date", ""));

    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
        ed.putString("name", etName.getText().toString());
        ed.putInt("age", age.getProgress());
        ed.putInt("group", spinner.getSelectedItemPosition());
        ed.putString("date", date.getText().toString());
        ed.commit();
    }
    @Override
    protected void onStop(){
        super.onStop();
        SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
        ed.putString("name", etName.getText().toString());
        ed.putInt("age", age.getProgress());
        ed.putInt("group", spinner.getSelectedItemPosition());
        ed.putString("date", date.getText().toString());
        ed.commit();
    }
    public void onClick(View v) {
        String name = "";
        switch (v.getId()){
            case R.id.btnSave:
                SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
                name = etName.getText().toString();
                ed.putString("name", name);
                ed.putInt("age", age.getProgress());
                ed.putInt("group", spinner.getSelectedItemPosition());
                ed.putString("date", date.getText().toString());
                ed.putString("photo", photoUri.toString());
                ed.commit();
                break;
            case R.id.btnLoad:
                SharedPreferences pref = getPreferences(MODE_PRIVATE);
                name = pref.getString("name", "");
                etName.setText(name);
                age.setProgress(pref.getInt("age", 0));
                spinner.setSelection(pref.getInt("group", 0));
                date.setText(pref.getString("date", ""));
                image.setImageURI(Uri.parse(pref.getString("photo", "")));
                break;
            default:
                break;
        }
    }
    public void callDatePicker(View v) {
        final Calendar cal = Calendar.getInstance();
        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String editTextDateParam = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                        date.setText(editTextDateParam);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    public void takePhoto(View v){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photoFile = null;
        try{
         photoFile = File.createTempFile("111", ".jpg", getExternalFilesDir(Environment.DIRECTORY_PICTURES));
        } catch (IOException ex){}
        photoUri = FileProvider.getUriForFile(this, "com.example.android.fileprovider", photoFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        startActivityForResult(intent, 1);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode==1 && data != null){
            image.setImageURI(photoUri);

        }
    }

}